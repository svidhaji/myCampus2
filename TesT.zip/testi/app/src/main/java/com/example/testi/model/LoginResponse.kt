package com.example.testi.model

import java.util.*

class LoginResponse (
    val token : String,
    val exp : Int,
    val user : User?,
    val roles : Array<String>
)
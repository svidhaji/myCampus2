package com.example.testi.model

import retrofit2.Call
import retrofit2.http.*

interface ApiService {

    @FormUrlEncoded
    @POST("https://mycampus-server.karage.fi/auth/login")
    @Headers("Content-Type: application/json")
    fun loginUser(
        @Field("email") email : String,
        @Field("password") password : String
    ): Call<LoginResponse>
}
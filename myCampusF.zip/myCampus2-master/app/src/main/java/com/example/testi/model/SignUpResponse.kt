package com.example.testi.model

data class SignUpResponse(
    val email : String,
    val msg : String
)

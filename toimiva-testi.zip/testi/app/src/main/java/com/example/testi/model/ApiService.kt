package com.example.testi.model

import retrofit2.Call
import retrofit2.http.*

interface ApiService {

    @POST("auth/login")
    @Headers("Content-Type: application/json")
    fun loginUser(
        @Body user: User
    ): Call<LoginResponse>
}
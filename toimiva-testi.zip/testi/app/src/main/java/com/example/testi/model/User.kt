package com.example.testi.model

data class User(
    val email : String,
    val password: String
)
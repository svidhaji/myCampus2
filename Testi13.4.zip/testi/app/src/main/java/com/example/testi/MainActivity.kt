package com.example.testi

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.net.toUri
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.example.testi.ui.parking.ParkingFragment
import com.example.testi.ui.restaurant.RestaurantFragment
import com.example.testi.ui.settings.SettingsFragment
import kotlinx.android.synthetic.main.fragment_settings.*
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

@Suppress("DEPRECATED_IDENTITY_EQUALS")
class MainActivity : AppCompatActivity() {

    lateinit var token: String
    lateinit var currentURL: String

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val PARKING_ROOT_URL = "https://mycampus-server.karage.fi/api/common/parking"
        //Endpoint urls for their respective parking areas
        val parkingURLP5 = "https://mycampus-server.karage.fi/api/common/parking/status/P5"
        val parkingURLP10 = "https://mycampus-server.karage.fi/api/common/parking/status/P10"
        val parkingURLP10TOP = "https://mycampus-server.karage.fi/api/common/parking/status/P10TOP"

        //Set of restaurant queue endpoints
        //https://mycampus-server.karage.fi/api/common/restaurant/Midpoint root url
        val restaurantURLS = arrayOf<String>("https://mycampus-server.karage.fi/api/common/restaurant/Midpoint/queue/1",
            "https://mycampus-server.karage.fi/api/common/restaurant/Midpoint/queue/2",
            "https://mycampus-server.karage.fi/api/common/restaurant/Midpoint/queue/3",
            "https://mycampus-server.karage.fi/api/common/restaurant/Midpoint/queue/4",
            "https://mycampus-server.karage.fi/api/common/restaurant/Midpoint/queue/5",
            "https://mycampus-server.karage.fi/api/common/restaurant/Midpoint/queue/6",
            "https://mycampus-server.karage.fi/api/common/restaurant/Midpoint/queue/7",
            "https://mycampus-server.karage.fi/api/common/restaurant/Midpoint/queue/8")

        val midpoint = "https://mycampus-server.karage.fi/api/common/restaurant/Midpoint?select=fill_percent"

        /*restaurantURLS.set(0,"https://mycampus-server.karage.fi/api/common/restaurant/Midpoint/queue/1")
        restaurantURLS[1] = "https://mycampus-server.karage.fi/api/common/restaurant/Midpoint/queue/2"
        restaurantURLS[2] = "https://mycampus-server.karage.fi/api/common/restaurant/Midpoint/queue/3"
        restaurantURLS[3] = "https://mycampus-server.karage.fi/api/common/restaurant/Midpoint/queue/4"
        restaurantURLS[4] = "https://mycampus-server.karage.fi/api/common/restaurant/Midpoint/queue/5"
        restaurantURLS[5] = "https://mycampus-server.karage.fi/api/common/restaurant/Midpoint/queue/6"
        restaurantURLS[6] = "https://mycampus-server.karage.fi/api/common/restaurant/Midpoint/queue/7"
        restaurantURLS[7] = "https://mycampus-server.karage.fi/api/common/restaurant/Midpoint/queue/8"*/

        fetchRestaurantFillRate().execute(midpoint)

        fetchRestaurantData().execute(restaurantURLS)

        fetchParkingData().execute(parkingURLP5)
        fetchParkingData().execute(parkingURLP10)
        fetchParkingData().execute(parkingURLP10TOP)

        val navView: BottomNavigationView = findViewById(R.id.nav_view)

        val navController = findNavController(R.id.nav_host_fragment)

        val myPreference = MyPreferences(this)
        var loginCount = myPreference.getLoginCount()
        val jwt = myPreference.getJwt()
        if (jwt != null) {
            loginCount++
        }
        myPreference.setLoginCount(loginCount)
        //set login count to textview if desired
        print(loginCount)





        //Navigation on touch listener. Pressing the navigation buttons will fetch the data to the associated fragment
        navView.setOnNavigationItemSelectedListener {

            if (it.itemId === R.id.navigation_parking) {
             /*   val transaction = supportFragmentManager.beginTransaction()
                transaction.addToBackStack(null)
                transaction.commit()*/

            } else if (it.itemId === R.id.navigation_restaurant) {
               /* val transaction = supportFragmentManager.beginTransaction()
                transaction.add(R.id.nav_host_fragment_container, newFragment)
                transaction.addToBackStack(null)
                transaction.commit()*/

            } else if (it.itemId === R.id.navigation_settings) {
                /*val newFragment = SettingsFragment()
                val transaction = supportFragmentManager.beginTransaction()
                transaction.replace(R.id.nav_host_fragment_container, newFragment)
                transaction.addToBackStack(null)
                transaction.commit()*/

                val textView: TextView? = findViewById(R.id.launchcount) as? TextView
                textView?.text = "launchcount: " + loginCount!!.toString()
            }
            return@setOnNavigationItemSelectedListener true
        }
        navView.setOnNavigationItemReselectedListener {

            if (it.itemId === R.id.navigation_parking) {
                //Do stuff
                fetchParkingData().execute(parkingURLP5)
                fetchParkingData().execute(parkingURLP10)
                fetchParkingData().execute(parkingURLP10TOP)

            } else if (it.itemId === R.id.navigation_restaurant) {
                //Do stuff

            } else if (it.itemId === R.id.navigation_settings) {
                //Do stuff
                val textView: TextView? = findViewById(R.id.launchcount) as? TextView
                textView?.text = "launchcount: " + loginCount!!.toString()

            }
        }

        val appBarConfiguration = AppBarConfiguration(setOf(
            R.id.navigation_parking, R.id.navigation_restaurant, R.id.navigation_settings))
        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)

    }


    @SuppressLint("SetTextI18n")
    fun setParkingProgress(percent: String) {
        val valuetopass: Int = percent.toInt()
        if (currentURL.equals("https://mycampus-server.karage.fi/api/common/parking/status/P5")) {
            findViewById<ProgressBar>(R.id.p5progress).setProgress(valuetopass, true)
            findViewById<TextView>(R.id.p5textprogress).text = "$valuetopass%"
        }
        if (currentURL.equals("https://mycampus-server.karage.fi/api/common/parking/status/P10")) {
            findViewById<ProgressBar>(R.id.p10progress).setProgress(valuetopass, true)
            findViewById<TextView>(R.id.p10textprogress).text = "$valuetopass%"
        }
        if (currentURL.equals("https://mycampus-server.karage.fi/api/common/parking/status/P10TOP")) {
            findViewById<ProgressBar>(R.id.p10insideprogress).setProgress(valuetopass, true)
            findViewById<TextView>(R.id.p10insidetextprogress).text = "$valuetopass%"
        } else {
            print("You should never get here")
            Log.d("setParking", "error with setParking")
        }
    }


    inner class fetchRestaurantData() : AsyncTask<Array<String>, Void, Array<String>>() {
        override fun onPreExecute() {
            super.onPreExecute()
        }

        // GET method for fetching data from API
        override fun doInBackground(vararg params: Array<String>): Array<String>? {
            Log.d("restaurantTask", "working...")

            token = MyPreferences.getInstance(applicationContext).getJwt().toString()
            val client = OkHttpClient()
            var responseArray = arrayOf<String>()
            var i = 0

            params[0].forEach {
                currentURL = it
                val url = URL(it)
                val request = Request.Builder()
                    .addHeader("Authorization", "$token")
                    .url(url)
                    .get()
                    .build()

                val response = client.newCall(request).execute()
                val responseBody = response.body!!.string()

                responseArray += responseBody
                i++
            }

            //Response
            println("Response Body: " + {responseArray})
            return responseArray
        }

        override fun onProgressUpdate(vararg values: Void?) {
            super.onProgressUpdate(*values)
        }

        override fun onPostExecute(result: Array<String>?) {

            super.onPostExecute(result)

            try {
                Log.d("restaurant", "postexecuting")
                val results = result
               results?.forEach {
                    // ,"queue_time":"1","ppl_counter ":"16"

                    val jsonObj = JSONObject(it)
                    val time = jsonObj.getString("queue_time")
                    val ppl = jsonObj.getString("ppl_counter ")
                    Log.d("restaurant", time)
                    Log.d("restaurant", ppl)
                    Log.d("restaurant", time)
                }
            } catch (e: Exception) {
            }
        }
    }

    inner class fetchParkingData() : AsyncTask<String, Void, String>() {
        override fun onPreExecute() {
            super.onPreExecute()
        }

        // GET method for fetching data from API
        // p5 capacity 650, p10 1025, p10top 205
        override fun doInBackground(vararg params: String): String? {
            Log.d("BGTASK", "alive?")
            currentURL = params[0]
            val client = OkHttpClient()
            val url = URL("${params[0]}")
            token = MyPreferences.getInstance(applicationContext).getJwt().toString()

            val request = Request.Builder()
                .addHeader("Authorization", "$token")
                .url(url)
                .get()
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body!!.string()
            //Response
            println("Response Body: " + responseBody)
            return responseBody
        }

        override fun onProgressUpdate(vararg values: Void?) {
            super.onProgressUpdate(*values)
        }

        override fun onPostExecute(result: String?) {

            super.onPostExecute(result)
            //SUCCESS RESPONSE:
            //{count: 20, percent: 3, capacity: 650, parkingId: 1}

            try {
                Log.d("BGTASK", "postexecuting")
                val jsonObj = JSONObject(result)
                val percent = jsonObj.getString("percent")
                print(percent)
                setParkingProgress(percent)
            } catch (e: Exception) {
            }
        }
    }

    inner class fetchRestaurantFillRate() : AsyncTask<String, Void, String>() {
        override fun onPreExecute() {
            super.onPreExecute()
        }

        // GET method for fetching data from API
        override fun doInBackground(vararg params: String): String? {
            currentURL = params[0]
            val client = OkHttpClient()
            val url = URL("${params[0]}")
            token = MyPreferences.getInstance(applicationContext).getJwt().toString()

            val request = Request.Builder()
                .addHeader("Authorization", "$token")
                .url(url)
                .get()
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body!!.string()
            //Response
            println("Response Body: " + responseBody)
            return responseBody
        }

        override fun onProgressUpdate(vararg values: Void?) {
            super.onProgressUpdate(*values)
        }

        override fun onPostExecute(result: String?) {

            super.onPostExecute(result)
            //SUCCESS RESPONSE:
            //{count: 20, percent: 3, capacity: 650, parkingId: 1}

            try {
                val jsonObj = JSONObject(result)
                val percent = jsonObj.getString("fill_percent")
                print(percent)
            } catch (e: Exception) {
            }
        }
    }
}

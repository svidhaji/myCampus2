package com.example.testi

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.testi.model.ApiClient
import com.example.testi.model.LoginResponse
import com.example.testi.model.UserLogin
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import kotlinx.android.synthetic.main.activity_login.*
import java.util.regex.Pattern

/**
 * Login class for Login
 */

class LoginActivity : AppCompatActivity() {

    lateinit var apiClient: ApiClient
    private val PASSWORD_PATTERN: Pattern = Pattern.compile(
        "^" +  //"(?=.*[0-9])" +         //at least 1 digit
                //"(?=.*[a-z])" +         //at least 1 lower case letter
                //"(?=.*[A-Z])" +         //at least 1 upper case letter
                "(?=.*[a-zA-Z])" +  //any letter
                "(?=\\S+$)" +  //no white spaces
                ".{4,}" +  //at least 4 characters
                "$"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        /**
         * Listener for register button
         */
        registerbutton.setOnClickListener {
            startActivity(Intent(this@LoginActivity, Register::class.java))
        }

        loginbutton.setOnClickListener {

            val email = emailf.text.toString().trim()
            val password = passwordf.text.toString().trim()

            if (email.isEmpty()) {
                emailf.error = "Enter your e-mail"
                emailf.requestFocus()
                return@setOnClickListener
            } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                emailf.error = "Enter a valid email address"
                return@setOnClickListener
            } else {
                emailf.error = null
            }


            if (password.isEmpty()) {
                passwordf.error = "Enter your password"
                passwordf.requestFocus()
                return@setOnClickListener
            } else if (!PASSWORD_PATTERN.matcher(password).matches()) {
                passwordf.error = "Password is too weak, enter better password"
                return@setOnClickListener
            } else {
                passwordf.error = null
            }
           ApiClient.instance.loginUser(UserLogin(email, password))
                .enqueue(object : Callback<LoginResponse> {
                    override fun onResponse(
                        call: Call<LoginResponse>,
                        response: Response<LoginResponse>
                    ) {
                     if (response.isSuccessful) {
                            println(response.body()?.token)

                            MyPreferences.getInstance(applicationContext).saveJwt(response.body()?.token!!)

                            val intent = Intent(applicationContext, MainActivity::class.java)
                            intent.flags =
                                Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK

                            startActivity(intent)
                        } else {
                            Toast.makeText(
                                applicationContext,
                                response.message(),
                                Toast.LENGTH_LONG
                            ).show()
                        }

                    }

                    override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                        Toast.makeText(applicationContext, t.message, Toast.LENGTH_LONG).show()
                    }

                })

        }
    }

   override fun onStart() {
        super.onStart()

        if (MyPreferences.getInstance(this).logged) {
            val intent = Intent(applicationContext, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK

            startActivity(intent)
        } else {
            val intent = Intent(applicationContext, Register::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK

            startActivity(intent)
        }
    }
}
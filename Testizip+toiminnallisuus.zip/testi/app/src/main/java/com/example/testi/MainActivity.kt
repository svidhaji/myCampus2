package com.example.testi

import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    lateinit var token: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val navView: BottomNavigationView = findViewById(R.id.nav_view)

        val navController = findNavController(R.id.nav_host_fragment)

        val appBarConfiguration = AppBarConfiguration(setOf(
                R.id.navigation_parking, R.id.navigation_restaurant, R.id.navigation_settings))
        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)


        val myPreference = MyPreferences(this)
        var loginCount = myPreference.getLoginCount()
        loginCount++
        myPreference.setLoginCount(loginCount)
        //set login count to textview if desired
        print(loginCount)


        //Endpoint urls for their respective parking areas
        val PARKING_ROOT_URL = "https://mycampus-server.karage.fi/api/common/parking"
        val parkingURLP5 = "https://mycampus-server.karage.fi/api/common/parking/status/:P5"
        val parkingURLP10 = "https://mycampus-server.karage.fi/api/common/parking/status/:P10"
        val parkingURLP10TOP = "https://mycampus-server.karage.fi/api/common/parking/status/:P10TOP"

        //Navigation on touch listener. Pressing the navigation buttons will fetch the data to the associated fragment
        navView.setOnNavigationItemSelectedListener {
            if (it.itemId === R.id.navigation_parking) {
                fetchParkingData().execute(parkingURLP5)
                fetchParkingData().execute(parkingURLP10)
                fetchParkingData().execute(parkingURLP10TOP)
            }
            else if (it.itemId === R.id.navigation_restaurant){
                //Do stuff
                //setContentView(R.id.)

            }

            else if (it.itemId === R.id.navigation_settings){
                //Do stuff

            }

            return@setOnNavigationItemSelectedListener true
        }
    }

    fun setLog() {
        val myPreference = MyPreferences(this)
        var loginCount = myPreference.getLoginCount()
        var log = loginCount.toString()
        findViewById<TextView>(R.id.launchcount).text = log
    }

fun getJTW(): String{
    val myPreference = MyPreferences(this)
    var JWT = myPreference.getJwt()
    JWT = token
    return token
}

   /* fun get(what: String) {
        val client = OkHttpClient()
        val url = URL(what)

        val request = Request.Builder()
            .addHeader("Authorization", "Bearer $token")
            .url(url)
            .get()
            .build()

        val response = client.newCall(request).execute()

        val responseBody = response.body!!.string()

        //Response
        println("Response Body: " + responseBody)
        } */

    inner class fetchParkingData() : AsyncTask<String, Void, String>() {
        override fun onPreExecute() {
            super.onPreExecute()
            /*ProgressBar */
        }
        // GET method for fetching data from API
        override fun doInBackground(vararg params: String): String? {
            Log.d("BGTASK", "alive?")
            val client = OkHttpClient()
            val url = URL("${params[0]}")

            val request = Request.Builder()
                //.addHeader("Authorization", "Bearer $token")
                .url(url)
                .get()
                .build()

            val response = client.newCall(request).execute()

            val responseBody = response.body!!.string()

            //Response
            println("Response Body: " + responseBody)
            return responseBody
        }

        override fun onProgressUpdate(vararg values: Void?) {
            super.onProgressUpdate(*values)
        }

        override fun onPostExecute(result: String?) {

            //super.onPostExecute(result)

            //SUCCESS RESPONSE:
            //{count: 20, percent: 3, capacity: 650, parkingId: 1}
            val testvalue = 48
            findViewById<ProgressBar>(R.id.p10progress).progress = testvalue
            findViewById<TextView>(R.id.p10textprogress).text = testvalue.toString() + "%"
            try {
                Log.d("BGTASK", "postexecuting")

                //alla olevat arvot käytetään sit on on se JWT body

                /*val jsonObj = JSONObject(result)
                val count = jsonObj.getInt("count")
                val capacity = jsonObj.getInt("capacity")
                val parkingId = jsonObj.getInt("parkingId")*/

                //kaikki alapuolella on esimerkkejä
                /*val main = jsonObj.getJSONObject("main")
                val sys = jsonObj.getJSONObject("sys")
                val wind = jsonObj.getJSONObject("wind")
                val weather = jsonObj.getJSONArray("weather").getJSONObject(0)

                val updatedAt:Long = jsonObj.getLong("dt")
                val updatedAtText = "Updated at: "+ SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.ENGLISH).format(Date(updatedAt*1000))
                val temp = main.getString("temp")+"°C"
                val tempMin = "Min Temp: " + main.getString("temp_min")+"°C"
                val tempMax = "Max Temp: " + main.getString("temp_max")+"°C"
                val pressure = main.getString("pressure")
                val humidity = main.getString("humidity")

                val sunrise:Long = sys.getLong("sunrise")
                val sunset:Long = sys.getLong("sunset")
                val windSpeed = wind.getString("speed")
                val weatherDescription = weather.getString("description")

                //val address = jsonObj.getString("name")+", "+sys.getString("country")
                //setContentView(R.layout.weatherview)
                *//* Populating extracted data into our views *//*
                //findViewById<TextView>(R.id.address).text = address
                val address = jsonObj.getString("name")+", "+sys.getString("country")

                findViewById<TextView>(R.id.address)?.text = address
                findViewById<TextView>(R.id.updated_at)?.text =  updatedAtText
                findViewById<TextView>(R.id.status)?.text = weatherDescription.capitalize()
                findViewById<TextView>(R.id.temp)?.text = temp
                findViewById<TextView>(R.id.temp_min)?.text = tempMin
                findViewById<TextView>(R.id.temp_max)?.text = tempMax
                findViewById<TextView>(R.id.sunrise)?.text = SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Date(sunrise*1000))
                findViewById<TextView>(R.id.sunset)?.text = SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Date(sunset*1000))
                findViewById<TextView>(R.id.wind)?.text = windSpeed
                findViewById<TextView>(R.id.pressure)?.text = pressure
                findViewById<TextView>(R.id.humidity)?.text = humidity
                findViewById<RelativeLayout>(R.id.mainContainer).visibility = View.VISIBLE*/

            } catch (e: Exception) {
            }


        }
    }
}

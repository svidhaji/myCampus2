package com.example.testi

import android.content.Context

class MyPreferences (context : Context) {

    val PREFERENCE_NAME = "SharedPreference1"
    val PREFERENCE_LOGIN_COUNT = "LoginCount"
    val JWT = "JasonWebToken"

    val preference = context.getSharedPreferences(PREFERENCE_NAME, Context.MODE_PRIVATE)

    fun getLoginCount () : Int {
        return  preference.getInt(PREFERENCE_LOGIN_COUNT, 0)
    }

    fun getJwt () : String {
        return preference.getString(JWT, null).toString()
    }

    fun setLoginCount(count:Int) {
        val editor = preference.edit()
        editor.putInt(PREFERENCE_LOGIN_COUNT, count)
        editor.apply()
    }

    fun setJwt(token:String) {
        val editor = preference.edit()
        editor.putString(JWT,token)
        editor.apply()
    }

}
package com.example.testi

import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.widget.Button
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import okhttp3.OkHttpClient
import okhttp3.Request

class MainActivity : AppCompatActivity() {

    lateinit var token: String
    lateinit var response: String


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val PARKING_ROOT_URL = "https://mycampus-server.karage.fi/api/common/parking"

        val navView: BottomNavigationView = findViewById(R.id.nav_view)

        val navController = findNavController(R.id.nav_host_fragment)

        val appBarConfiguration = AppBarConfiguration(setOf(
                R.id.navigation_parking, R.id.navigation_restaurant, R.id.navigation_settings))
        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)

        val parkingURLP5 = "https://mycampus-server.karage.fi/api/common/parking/status/:P5"
        val parkingURLP10 = "https://mycampus-server.karage.fi/api/common/parking/status/:P10"
        val parkingURLP10TOP = "https://mycampus-server.karage.fi/api/common/parking/status/:P10TOP"
        fetchParkingData().execute(parkingURLP10)
        val parkstr = "navigation_parking"
        navView.setOnNavigationItemSelectedListener {
            if (it.itemId.toString() == parkstr) {
                fetchParkingData().execute(parkingURLP10)

            }
            return@setOnNavigationItemSelectedListener true
        }

        val myPreference = MyPreferences(this)
        var loginCount = myPreference.getLoginCount()
        loginCount++
        myPreference.setLoginCount(loginCount)
        //set login count to textview if desired.tos
    }

fun getJTW(): String{
    val myPreference = MyPreferences(this)
    var JWT = myPreference.getJwt()
    JWT = token
    return token
}

    fun get(what: String) {
        val client = OkHttpClient()
        val url = URL(what)

        val request = Request.Builder()
            .addHeader("Authorization", "Bearer $token")
            .url(url)
            .get()
            .build()

        val response = client.newCall(request).execute()

        val responseBody = response.body!!.string()

        //Response
        println("Response Body: " + responseBody)
        }

    inner class fetchParkingData() : AsyncTask<String, Void, String>() {
        override fun onPreExecute() {
            super.onPreExecute()
            /* Showing the ProgressBar, Making the main design GONE */
//           findViewById<ProgressBar>(R.id.loader).visibility = View.VISIBLE
            //  findViewById<RelativeLayout>(R.id.mainContainer).visibility = View.VISIBLE
            //findViewById<TextView>(R.id.errorText).visibility = View.GONE
        }

        override fun doInBackground(vararg params: String): String? {
            Log.d("BGTASK", "alive?")
            val client = OkHttpClient()
            val url = URL("${params[0]}")

            val request = Request.Builder()
                //.addHeader("Authorization", "Bearer $token")
                .url(url)
                .get()
                .build()

            val response = client.newCall(request).execute()

            val responseBody = response.body!!.string()

            //Response
            println("Response Body: " + responseBody)
            return responseBody
        }

        override fun onProgressUpdate(vararg values: Void?) {
            super.onProgressUpdate(*values)
        }

        override fun onPostExecute(result: String?) {

            super.onPostExecute(response)

            try {
                Log.d("BGTASK", "postexecuting")
            /*    val jsonObj = JSONObject(result)
                val main = jsonObj.getJSONObject("main")
                val sys = jsonObj.getJSONObject("sys")
                val wind = jsonObj.getJSONObject("wind")
                val weather = jsonObj.getJSONArray("weather").getJSONObject(0)

                val updatedAt:Long = jsonObj.getLong("dt")
                val updatedAtText = "Updated at: "+ SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.ENGLISH).format(Date(updatedAt*1000))
                val temp = main.getString("temp")+"°C"
                val tempMin = "Min Temp: " + main.getString("temp_min")+"°C"
                val tempMax = "Max Temp: " + main.getString("temp_max")+"°C"
                val pressure = main.getString("pressure")
                val humidity = main.getString("humidity")

                val sunrise:Long = sys.getLong("sunrise")
                val sunset:Long = sys.getLong("sunset")
                val windSpeed = wind.getString("speed")
                val weatherDescription = weather.getString("description")

                //val address = jsonObj.getString("name")+", "+sys.getString("country")
                //setContentView(R.layout.weatherview)
                *//* Populating extracted data into our views *//*
                //findViewById<TextView>(R.id.address).text = address
                val address = jsonObj.getString("name")+", "+sys.getString("country")

                findViewById<TextView>(R.id.address)?.text = address
                findViewById<TextView>(R.id.updated_at)?.text =  updatedAtText
                findViewById<TextView>(R.id.status)?.text = weatherDescription.capitalize()
                findViewById<TextView>(R.id.temp)?.text = temp
                findViewById<TextView>(R.id.temp_min)?.text = tempMin
                findViewById<TextView>(R.id.temp_max)?.text = tempMax
                findViewById<TextView>(R.id.sunrise)?.text = SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Date(sunrise*1000))
                findViewById<TextView>(R.id.sunset)?.text = SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Date(sunset*1000))
                findViewById<TextView>(R.id.wind)?.text = windSpeed
                findViewById<TextView>(R.id.pressure)?.text = pressure
                findViewById<TextView>(R.id.humidity)?.text = humidity
                findViewById<RelativeLayout>(R.id.mainContainer).visibility = View.VISIBLE*/

            } catch (e: Exception) {
            }


        }
    }
}
